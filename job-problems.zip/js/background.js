chrome.runtime.onInstalled.addListener(function () {
    chrome.storage.sync.get(function (obj) {
        var JRN = 'PO150';
        var autoSubmit = false;
        if (obj['JRN'] === undefined || obj['JRN'] === null) {
            chrome.storage.sync.set({ JRN: JRN }, function () { });
        }
        if (obj['autoSubmit'] === undefined || obj['autoSubmit'] === null) {
            chrome.storage.sync.set({ autoSubmit: autoSubmit }, function () { });
        }
    });
});

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.type == "getJRN") {
            getJRN(request, sender, sendResponse);
            return true;
        }
        if (request.type == "setJRN") {
            setJRN(request, sender, sendResponse);
            return true;
        }
    });

function getJRN(request, sender, sendResponse) {
    chrome.storage.sync.get(function (obj) {
        let findJRN = obj['JRN'];
        let autoSubmit = obj['autoSubmit'];
        if (findJRN) {
            var resp = sendResponse;
            resp({ result: findJRN, autoSubmit: autoSubmit });
        }
    });
}

function setJRN(request, sender, sendResponse) {
    chrome.storage.sync.set({ JRN: request.JRN, autoSubmit: request.autoSubmit }, function () { });
}

function newTab(request, sender, sendResponse) {
    chrome.storage.sync.get(function (obj) {
        let validLicense = obj['active'];
        if (validLicense) {
            console.log('valid license')
            var newURL = "https://www.chemistwarehouse.com.au/search/go?w=" + request.searchQuery;
            chrome.tabs.create({ url: newURL });
        } else {
            console.log('invalid license');
        }
    });
    //var newURL = "https://www.chemistwarehouse.com.au/search/go?w=" + request.searchQuery;
    //chrome.tabs.create({ url: newURL });
}

function checkDB(request, sender, sendResponse) {
    chrome.storage.sync.get(function (obj) {
        let validLicense = obj['active'];
        if (validLicense) {
            var resp = sendResponse;
            $.ajax({
                type: "GET",
                dataType: "json",
                url: obj['server'] + "/partcode?code=" + request.partcode + "&name=" + request.name,
                success: function (data) {
                    resp({ result: data, element: request.element });
                }
            });
        } else {
            console.log('invalid license');
        }
    });
}

function checkBarcode(request, sender, sendResponse) {
    chrome.storage.sync.get(function (obj) {
        let validLicense = obj['active'];
        if (validLicense) {
            console.log('valid license');
            var resp = sendResponse;
            $.ajax({
                type: "GET",
                dataType: "json",
                url: obj['server'] + "/barcode?code=" + request.partcode,
                success: function (data) {
                    let newURL = "https://www.chemistwarehouse.com.au/search/go?w=" + data.data[0].TradeName;
                    chrome.tabs.create({ url: newURL });
                    resp({ result: data, element: request.element });
                },
                error: function (data) {
                    let newURL = "https://www.chemistwarehouse.com.au/search/go?w=" + request.partcode;
                    chrome.tabs.create({ url: newURL });
                    resp({ result: data, element: request.element });
                }
            });
        } else {
            alert('invalid license');
        }

    });
}